# Verification report

## Top-1 accuracy
- OK All values within tolerance.

## Top-5 accuracy
- OK All values within tolerance.

## Sensitivity & interaction
- OK All sensitivity/interaction values within tolerance.
