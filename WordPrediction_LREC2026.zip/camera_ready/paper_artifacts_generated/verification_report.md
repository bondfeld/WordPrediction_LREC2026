# Verification report

## Top-1 accuracy
- ✅ All values within tolerance.

## Top-5 accuracy
- ✅ All values within tolerance.

## Sensitivity & interaction
- ✅ All sensitivity/interaction values within tolerance.
